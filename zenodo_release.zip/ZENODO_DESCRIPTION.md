# Zenodo Repository Description

## Title
Multi-Signal TrustFed-Honeypot: A Trust-Aware Federated Learning Framework for Intrusion Detection with Behavioral Multi-Signal Trust Fusion

## Description

This repository contains the complete implementation and experimental results for **TrustFed-Honeypot**, a behavioral multi-signal trust fusion framework for federated intrusion detection systems. The framework addresses critical security and reliability gaps in distributed honeypot and IDS deployments by integrating four complementary reliability signals—detection accuracy, performance stability, update drift, and predictive uncertainty—into a unified trust score.

### Key Contributions

1. **Multi-Signal Trust Fusion**: Unlike existing single-metric trust approaches, the framework combines four behavioral indicators (accuracy, stability, drift, uncertainty) to provide robust client reliability estimation in adversarial and heterogeneous environments.

2. **Trust-Weighted Data Retraining**: Implements sub-linear trust-weighted aggregation (trust^0.8) with data-level retraining, enabling the global model to learn primarily from reliable clients while maintaining data diversity.

3. **Cross-Dataset Validation**: Evaluated on both benchmark (CTU-13) and real-world honeypot telemetry, demonstrating consistent performance improvements across different data sources and attack characteristics.

### Experimental Results

**CTU-13 Benchmark Dataset (Mean ± Std Dev across 4 trials):**
- Trust-Aware: 72.81% ± 0.96% accuracy, 84.12% ± 0.69% F1-Score (99.9% of Centralized performance)
- Outperforms FedAvg by +31.50 ± 17.39 percentage points accuracy and +42.11 ± 26.93 percentage points F1-Score
- Achieves 9.92% False Negative Rate (vs 43.11% for FedAvg, 39.88% for Centralized)
- Statistical validation: 5 independent trials with different random seeds (42-46)

**Real Honeypot Dataset (Mean ± Std Dev across 5 trials):**
- Trust-Aware: 70.89% ± 9.44% accuracy, 80.14% ± 7.84% F1-Score
- Outperforms FedAvg by +4.13 ± 13.35 percentage points accuracy and +3.83 ± 11.64 percentage points F1-Score
- Outperforms Centralized by +10.91 ± 15.71 percentage points accuracy (demonstrates effectiveness of quality-based filtering)
- Achieves 23.97% False Negative Rate (vs 30.34% for FedAvg, 39.49% for Centralized)

### Technical Features

- **Model-Agnostic Framework**: Validated across four model architectures (Logistic Regression, MLP, Random Forest, XGBoost)
- **Multi-Round Federated Learning**: Adaptive trust updates across multiple communication rounds with trust evolution tracking
- **Heterogeneous Client Support**: Handles varying data quality (high, medium, low, compromised clients)
- **Privacy-Preserving**: Feature vectors (preprocessed statistical features) transmitted, not raw telemetry
- **Statistical Validation**: All experiments conducted with 5 independent trials, results reported as mean ± standard deviation
- **Comprehensive Evaluation**: Includes accuracy, precision, recall, F1-score, FPR, FNR, confusion matrices, and ROC curves

### Repository Contents

- **Source Code**: Complete Python implementation of federated learning system
  - `src/federated_client.py`: Client-side training and trust signal computation
  - `src/federated_server.py`: Server-side aggregation with trust-aware mechanisms
  - `src/trust_manager.py`: Multi-signal trust fusion and adaptive trust updates
  - `experiment.py`: Main experiment orchestration script

- **Configuration Files**: 
  - `config/trust_config.json`: Trust fusion weights and parameters
  - Optimized weights: λ1=1.0 (accuracy), λ2=0.3 (stability), λ3=0.2 (drift), λ4=0.2 (uncertainty)
  - Trust exponent: β=0.8 (sub-linear weighting)

- **Documentation**:
  - `README.md`: Comprehensive project documentation and usage guide
  - `EXECUTIVE_SUMMARY.md`: Research findings and experimental results
  - `ARCHITECTURE.md`: System architecture and design decisions
  - Research paper: `results/plots/overleaf.tex`

- **Experimental Results**:
  - Performance metrics for all three approaches (Centralized, FedAvg, Trust-Aware)
  - Trust evolution plots and visualizations
  - Confusion matrices for both evaluation scenarios

### Usage

The framework can be run with:
```bash
python experiment.py --data-dir data/CSVs --num-rounds 10 --multi-signal-trust
```

See `README.md` for detailed installation and usage instructions.

### Requirements

- Python 3.8+
- scikit-learn, pandas, numpy, matplotlib, seaborn
- See `requirements.txt` for complete dependencies

### Citation

If you use this code or results in your research, please cite:

```
[Citation will be added once paper is published]
```

### Keywords

federated learning, intrusion detection systems, honeypots, trust-aware aggregation, multi-signal trust fusion, distributed cybersecurity, non-IID data, behavioral trust modeling, privacy-preserving machine learning, network security

### License

[Specify license - e.g., MIT, Apache 2.0, etc.]

### Related Publications

- Research paper: "Multi-Signal TrustFed-Honeypot: A Trust-Aware Federated Intrusion Detection Framework with Comparative Evaluation"
- Conference/Journal: [To be specified]

### Contact

For questions or issues, please open an issue in the repository or contact the authors.

---

**Note**: This repository accompanies the research paper on Multi-Signal TrustFed-Honeypot. The code is fully reproducible with the provided configuration files and random seed (42).
