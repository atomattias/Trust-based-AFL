# Data files should be downloaded separately or obtained from original sources
# CTU-13 dataset: https://www.stratosphereips.org/datasets-ctu13
# Honeypot data: Contact authors for access
