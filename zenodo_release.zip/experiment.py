"""
Main experiment script for Trust-Aware Federated Honeypot Learning.

This script orchestrates three approaches:
1. Centralized Learning (upper bound)
2. Standard Federated Learning (equal weights)
3. Trust-Aware Federated Learning (proposed method)
"""

import os
import sys
import json
import pandas as pd
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional

# For statistical tests
try:
    from scipy import stats
except ImportError:
    stats = None
    print("Warning: scipy not available. Statistical tests will be skipped.")

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from preprocessing import load_client_data, prepare_labels, prepare_features, split_data
from local_training import train_local_model
from federated_client import FederatedClient
from federated_server import FedAvgAggregator, TrustAwareAggregator, EnsembleAggregator, TrustManager
from evaluation import evaluate_model_on_test, generate_results_summary
from visualization import save_all_visualizations
from config_loader import load_trust_config, apply_trust_config


class ExperimentRunner:
    """Orchestrates the complete experiment."""
    
    def __init__(
        self,
        data_dir: str = 'data/CSVs',
        model_type: str = 'random_forest',
        random_state: int = 42,
        test_csv: Optional[str] = None,
        num_rounds: int = 1,
        trust_alpha: float = 0.7,
        trust_storage_dir: Optional[str] = None,
        use_multi_signal: bool = False
    ):
        """
        Initialize the experiment runner.
        
        Args:
            data_dir: Directory containing CSV files
            model_type: Type of model ('random_forest' or 'logistic_regression')
            random_state: Random seed
            test_csv: Optional path to test CSV (if None, will use one of the client CSVs)
            num_rounds: Number of federated learning rounds (1 = single round, >1 = multi-round with adaptive trust).
                        Note: Multi-round mode (recommended: 10 rounds) typically yields better Trust-Aware performance
                        than single-round mode, often outperforming Centralized learning.
            trust_alpha: History weight for adaptive trust (0.7 = 70% old, 30% new)
            trust_storage_dir: Directory to store trust history (None = in-memory only)
        """
        self.data_dir = Path(data_dir)
        self.model_type = model_type
        self.random_state = random_state
        self.test_csv = test_csv
        self.num_rounds = num_rounds
        
        self.clients = []
        self.client_updates = []
        self.test_data = None
        
        # Initialize TrustManager for adaptive trust (if multi-round)
        if num_rounds > 1:
            # Load configuration
            trust_config = load_trust_config()
            
            # Override with command-line arguments if provided
            if trust_storage_dir is None:
                trust_storage_dir = trust_config.get('trust_manager', {}).get('storage_dir', 'results/trust_history')
            
            # Create TrustManager with config or defaults
            trust_mgr_config = trust_config.get('trust_manager', {})
            
            # Get lambda weights from config if available
            lambda_weights = None
            if use_multi_signal:
                multi_signal_config = trust_config.get('multi_signal', {})
                lambda_weights = {
                    'lambda1': multi_signal_config.get('lambda1', 1.0),  # Accuracy
                    'lambda2': multi_signal_config.get('lambda2', 0.3),  # Stability
                    'lambda3': multi_signal_config.get('lambda3', 0.2),  # Drift
                    'lambda4': multi_signal_config.get('lambda4', 0.2)   # Uncertainty
                }
            
            # Use trust_alpha from argument if provided, otherwise use config
            final_alpha = trust_alpha if trust_alpha != 0.7 else trust_mgr_config.get('alpha', 0.7)
            
            self.trust_manager = TrustManager(
                alpha=final_alpha,
                decay_rate=trust_mgr_config.get('decay_rate', 0.95),
                anomaly_threshold=trust_mgr_config.get('anomaly_threshold', 0.2),
                initial_trust=trust_mgr_config.get('initial_trust', 0.5),
                storage_dir=trust_storage_dir,
                use_multi_signal=use_multi_signal,
                lambda_weights=lambda_weights
            )
            
            # Store use_multi_signal flag
            self.use_multi_signal = use_multi_signal
            
            # Apply any additional config (but preserve alpha if explicitly set)
            apply_trust_config(self.trust_manager, trust_config)
            # Override alpha again after apply_trust_config to ensure command-line arg takes precedence
            if trust_alpha != 0.7:
                self.trust_manager.alpha = trust_alpha
            
            # Load existing trust histories if available
            self.trust_manager.load_all_trust_histories()
        else:
            self.trust_manager = None
            self.use_multi_signal = False
        
    def discover_client_files(self) -> List[str]:
        """
        Discover all CSV files in the data directory.
        Prefers heterogeneous clients if they exist, then mixed files, then original files.
        
        Returns:
            List of CSV file paths
        """
        csv_files = list(self.data_dir.glob('*.csv'))
        
        # Filter out benign files for client selection (we'll use them for mixing)
        all_attack_files = [f for f in csv_files if 'benign' not in f.name.lower()]
        benign_files = [f for f in csv_files if 'benign' in f.name.lower()]
        
        # Check for heterogeneous clients (created by create_heterogeneous_clients.py)
        heterogeneous_files = [f for f in all_attack_files if any(
            tier in f.name.lower() for tier in ['high_quality', 'medium_quality', 'low_quality', 'compromised']
        )]
        
        # Prefer mixed files if they exist (created by prepare_realistic_data.py)
        mixed_files = [f for f in all_attack_files if f.name.startswith('mixed_') and f not in heterogeneous_files]
        original_files = [f for f in all_attack_files if not f.name.startswith('mixed_') and f not in heterogeneous_files]
        
        if heterogeneous_files:
            # Use heterogeneous clients (they have varying quality)
            attack_files = heterogeneous_files
            print(f"Found {len(heterogeneous_files)} heterogeneous client files (varying quality)")
            print(f"  This will demonstrate weaknesses of Centralized and FedAvg!")
            print(f"  High-quality, medium-quality, low-quality, and compromised clients detected")
        elif mixed_files:
            # Use mixed files (they contain both benign and attack samples)
            attack_files = mixed_files
            print(f"Found {len(mixed_files)} mixed CSV files (with benign samples)")
            print(f"Found {len(original_files)} original attack CSV files (ignored)")
        else:
            # Fall back to original files
            attack_files = original_files
            print(f"Found {len(original_files)} attack CSV files")
            if len(mixed_files) == 0:
                print("  (Tip: Run prepare_realistic_data.py to create mixed datasets)")
                print("  (Tip: Run create_heterogeneous_clients.py to create heterogeneous clients)")
        
        print(f"Found {len(benign_files)} benign CSV files")
        
        return [str(f) for f in attack_files], [str(f) for f in benign_files]
    
    def prepare_test_data(self, test_csv_path: str) -> tuple:
        """
        Prepare test dataset.
        
        Args:
            test_csv_path: Path to test CSV file
            
        Returns:
            X_test, y_test
        """
        print(f"\nLoading test data from {test_csv_path}")
        df_test = load_client_data(test_csv_path)
        df_test = prepare_labels(df_test)
        X_test = prepare_features(df_test)
        y_test = df_test['label']
        
        print(f"Test set: {len(X_test)} samples, {X_test.shape[1]} features")
        print(f"Test set class distribution: {(y_test == 0).sum()} benign, {(y_test == 1).sum()} attack")
        
        return X_test, y_test
    
    def setup_clients(self, attack_files: List[str], benign_files: List[str], num_clients: Optional[int] = None) -> None:
        """
        Set up federated clients from CSV files.
        
        Args:
            attack_files: List of attack CSV file paths
            benign_files: List of benign CSV file paths (for mixing)
            num_clients: Number of clients to use (None = use all)
        """
        if num_clients is not None:
            attack_files = attack_files[:num_clients]
        
        # Exclude problematic clients (e.g., those with 100% accuracy despite corruption)
        excluded_clients = ['heartbleed']  # Exclude heartbleed compromised client with 100% accuracy
        original_count = len(attack_files)
        attack_files = [f for f in attack_files if not any(excluded in Path(f).name.lower() for excluded in excluded_clients)]
        if len(attack_files) < original_count:
            print(f"\n⚠️  Excluding {original_count - len(attack_files)} problematic client(s): {excluded_clients}")
        
        print(f"\nSetting up {len(attack_files)} federated clients...")
        
        for idx, attack_file in enumerate(attack_files):
            client_id = f"client_{idx+1}_{Path(attack_file).stem}"
            print(f"  Setting up {client_id}...")
            
            # Extract quality from filename if present (e.g., 'high_quality_client_1.csv')
            import re
            quality_match = re.search(r'(high|medium|low|compromised)_quality', Path(attack_file).name)
            client_quality = quality_match.group(1) if quality_match else 'unknown'
            
            # Debug: Check if quality was extracted
            if 'compromised' in Path(attack_file).name.lower() and client_quality != 'compromised':
                # Try alternative pattern: client_X_compromised_...
                alt_match = re.search(r'_compromised_', Path(attack_file).name)
                if alt_match:
                    client_quality = 'compromised'
            
            # CRITICAL FIX: Find original clean source file for validation
            # For heterogeneous clients (compromised/low/medium), use clean validation set
            clean_validation_source = None
            # FIX: Only use clean validation for medium/low clients, NOT compromised
            # Compromised clients should use CORRUPTED validation to get low trust scores
            if client_quality in ['low', 'medium']:
                # Extract source file name from heterogeneous client filename
                # Pattern: client_X_compromised_mixed_Y.csv -> mixed_Y.csv
                # Handle cases like: mixed_ssh_patator-new.csv (with hyphens)
                filename = Path(attack_file).name
                # Find "mixed_" followed by everything until ".csv"
                source_match = re.search(r'mixed_[^.]+\.csv', filename)
                if source_match:
                    source_filename = source_match.group(0)
                    # Look for original source in data/CSVs directory
                    original_source = Path('data/CSVs') / source_filename
                    if original_source.exists():
                        clean_validation_source = str(original_source)
                        print(f"\n    ✅ FOUND CLEAN VALIDATION SOURCE for {client_id}: {source_filename}")
                    else:
                        print(f"\n    ⚠️  Clean source not found: {source_filename} (looking in data/CSVs/)")
                else:
                    print(f"\n    ⚠️  Could not extract source filename from: {filename}")
            elif client_quality == 'compromised':
                # CRITICAL: Compromised clients MUST use CORRUPTED validation
                # Training data is corrupted → model learns wrong patterns
                # Corrupted validation → model performs poorly (even on corrupted data) → LOW trust score
                # Using clean validation can give high trust if model somehow generalizes
                # Using corrupted validation ensures trust reflects the corrupted quality
                clean_validation_source = None  # Use corrupted validation data
                print(f"\n    ✅ COMPROMISED CLIENT: Using CORRUPTED validation (no clean source)")
                print(f"        Training: CORRUPTED → Model learns wrong patterns")
                print(f"        Validation: CORRUPTED → Model performs poorly → LOW trust")
            else:
                print(f"    (High-quality client - no clean validation needed)")
            
            client = FederatedClient(
                client_id=client_id,
                data_path=attack_file,
                model_type=self.model_type,
                random_state=self.random_state,
                client_quality=client_quality,
                clean_validation_source=clean_validation_source
            )
            
            # Load and prepare data
            client.load_data()
            
            # Optionally mix in some benign data (simulate realistic honeypot)
            # For simplicity, we'll use the attack data as-is
            # In a real scenario, you might sample benign data and mix it
            
            self.clients.append(client)
        
        print(f"Successfully set up {len(self.clients)} clients")
    
    def train_clients(self) -> None:
        """Train all client models."""
        print("\n" + "="*60)
        print("Training Local Models at Each Client")
        print("="*60)
        
        for client in self.clients:
            print(f"\nTraining {client.client_id}...")
            client.train()
            client.evaluate()
            client.compute_trust()
            
            info = client.get_info()
            print(f"  Train samples: {info['train_samples']}")
            print(f"  Val samples: {info['val_samples']}")
            print(f"  Val Accuracy: {info['val_accuracy']:.4f}")
            print(f"  Trust Score: {info['trust_score']:.4f}")
        
        # Collect model updates
        self.client_updates = [client.get_model_update() for client in self.clients]
        
        print(f"\n✓ All {len(self.clients)} clients trained successfully")
    
    def approach_1_centralized(self, X_test: pd.DataFrame, y_test: pd.Series) -> Dict[str, Any]:
        """
        Approach 1: Centralized Learning.
        
        In heterogeneous client scenarios, this approach is weak because:
        - Cannot filter bad data from low-quality clients
        - All data (good + bad) is combined and trained together
        - Bad clients degrade the global model
        - No concept of dynamic trust (single round only)
        
        Args:
            X_test: Test features
            y_test: Test labels
            
        Returns:
            Results dictionary
        """
        print("\n" + "="*60)
        print("Approach 1: Centralized Learning")
        print("="*60)
        print("Note: In heterogeneous scenarios, Centralized is weak because")
        print("      it cannot filter bad data from low-quality clients.")
        print("      Also, Centralized has no dynamic trust concept (single round).")
        
        # Combine all training data from all clients
        print("\nCombining all client data (good + bad)...")
        all_X_train = []
        all_y_train = []
        client_qualities = []
        
        for client in self.clients:
            all_X_train.append(client.X_train)
            all_y_train.append(client.y_train)
            
            # Detect client quality from filename
            client_path = Path(client.data_path)
            if 'high_quality' in client_path.name.lower():
                client_qualities.append('high')
            elif 'medium_quality' in client_path.name.lower():
                client_qualities.append('medium')
            elif 'low_quality' in client_path.name.lower():
                client_qualities.append('low')
            elif 'compromised' in client_path.name.lower():
                client_qualities.append('compromised')
            else:
                client_qualities.append('unknown')
        
        # Ensure all DataFrames have the same columns before concatenating
        all_columns = set()
        for df in all_X_train:
            all_columns.update(df.columns)
        all_columns = sorted(list(all_columns))
        
        # Reindex all DataFrames to have the same columns (missing columns will be NaN)
        all_X_train_aligned = [df.reindex(columns=all_columns) for df in all_X_train]
        
        X_combined = pd.concat(all_X_train_aligned, ignore_index=True)
        y_combined = pd.concat(all_y_train, ignore_index=True)
        
        # Fill any NaN values that may have been created by missing columns
        X_combined = X_combined.fillna(0)
        
        print(f"Combined dataset: {len(X_combined)} samples")
        print(f"Class distribution: {(y_combined == 0).sum()} benign, {(y_combined == 1).sum()} attack")
        
        # Report client quality distribution
        if any(q != 'unknown' for q in client_qualities):
            quality_counts = {}
            for q in client_qualities:
                quality_counts[q] = quality_counts.get(q, 0) + 1
            print(f"\nClient quality distribution:")
            for quality, count in sorted(quality_counts.items()):
                print(f"  {quality}: {count} clients")
            print("  ⚠️  Centralized cannot filter bad data - all clients contribute equally!")
            print("  ⚠️  Centralized has no dynamic trust - single round only!")
        
        # Train centralized model
        print("\nTraining centralized model on combined data...")
        centralized_model, train_metrics = train_local_model(
            X_combined,
            y_combined,
            model_type=self.model_type,
            random_state=self.random_state
        )
        
        print(f"Training accuracy: {train_metrics['train_accuracy']:.4f}")
        
        # Align test set features with training features
        print("\nAligning test set features with training features...")
        X_test_aligned = X_test.reindex(columns=X_combined.columns, fill_value=0)
        
        # Evaluate on test set
        print("\nEvaluating on test set...")
        results = evaluate_model_on_test(centralized_model, X_test_aligned, y_test)
        
        print(f"\nTest Accuracy: {results['accuracy']:.4f}")
        print(f"Test F1-Score: {results['f1_score']:.4f}")
        print(f"Test Precision: {results['precision']:.4f}")
        print(f"Test Recall: {results['recall']:.4f}")
        print(f"False Positive Rate: {results['false_positive_rate']:.4f}")
        
        # Add note about weakness in heterogeneous scenarios
        if any(q in ['low', 'compromised'] for q in client_qualities):
            print("\n⚠️  Centralized weakness: Bad clients degrade model performance")
            print("    Cannot filter or weight clients by quality")
            print("    No dynamic trust - single round only (cannot adapt)")
        
        return results
    
    def approach_2_federated_equal_weight(self, X_test: pd.DataFrame, y_test: pd.Series) -> Dict[str, Any]:
        """
        Approach 2: Standard Federated Learning (equal weights - FedAvg).
        
        In heterogeneous client scenarios, this approach is weak because:
        - All clients have equal weight (1/N)
        - Cannot differentiate good vs bad clients
        - Low-quality clients have same influence as high-quality
        - Weights stay constant (no adaptation)
        
        Args:
            X_test: Test features
            y_test: Test labels
            
        Returns:
            Results dictionary
        """
        print("\n" + "="*60)
        print("Approach 2: Standard Federated Learning (Equal Weights - FedAvg)")
        print("="*60)
        print("Note: In heterogeneous scenarios, FedAvg is weak because")
        print("      all clients have equal weight - cannot prioritize good clients.")
        
        # Report client trust scores to show heterogeneity
        trust_scores = [update.get('trust', 0) for update in self.client_updates]
        if trust_scores:
            print(f"\nClient trust scores (validation accuracy):")
            for i, (update, trust) in enumerate(zip(self.client_updates, trust_scores)):
                client_id = update.get('client_id', f'client_{i+1}')
                print(f"  {client_id}: {trust:.4f}")
            
            trust_range = max(trust_scores) - min(trust_scores)
            print(f"\nTrust score range: {min(trust_scores):.4f} - {max(trust_scores):.4f} (range: {trust_range:.4f})")
            if trust_range > 0.3:
                print("  ⚠️  High heterogeneity detected - FedAvg equal weighting is suboptimal!")
            print(f"  FedAvg weight per client: {1.0/len(self.client_updates):.4f} (equal for all)")
        
        # Use FedAvgAggregator with retraining (true FedAvg)
        print("\nAggregating client models with equal weights using true FedAvg (retraining)...")
        print("  All clients contribute equally (1/{})".format(len(self.client_updates)))
        aggregator = FedAvgAggregator(model_type=self.model_type)
        global_model = aggregator.aggregate(self.client_updates, use_retraining=True)
        
        # Align test set features with training features (use aggregator's training columns)
        if hasattr(aggregator, 'training_feature_columns') and aggregator.training_feature_columns:
            X_test_aligned = X_test.reindex(columns=aggregator.training_feature_columns, fill_value=0)
        elif len(self.clients) > 0:
            # Fallback: use all unique columns from all clients
            all_train_columns = set()
            for client in self.clients:
                all_train_columns.update(client.X_train.columns)
            all_train_columns = sorted(list(all_train_columns))
            X_test_aligned = X_test.reindex(columns=all_train_columns, fill_value=0)
        else:
            X_test_aligned = X_test
        
        # Evaluate global model
        results = evaluate_model_on_test(global_model, X_test_aligned, y_test)
        
        print(f"\nTest Accuracy: {results['accuracy']:.4f}")
        print(f"Test F1-Score: {results['f1_score']:.4f}")
        print(f"Test Precision: {results['precision']:.4f}")
        print(f"Test Recall: {results['recall']:.4f}")
        print(f"False Positive Rate: {results['false_positive_rate']:.4f}")
        
        # Add note about weakness
        if trust_scores and trust_range > 0.3:
            print("\n⚠️  FedAvg weakness: Equal weighting doesn't differentiate client quality")
            print("    Low-quality clients have same influence as high-quality clients")
            print("    Weights stay constant - cannot adapt to changing conditions")
        
        return results
    
    def approach_3_trust_aware(self, X_test: pd.DataFrame, y_test: pd.Series) -> Dict[str, Any]:
        """
        Approach 3: Trust-Aware Federated Learning (proposed method).
        
        Supports both single-round (static trust) and multi-round (adaptive trust) modes.
        
        Args:
            X_test: Test features
            y_test: Test labels
            
        Returns:
            Results dictionary
        """
        if self.num_rounds > 1:
            return self._approach_3_multi_round(X_test, y_test)
        else:
            return self._approach_3_single_round(X_test, y_test)
    
    def _approach_3_single_round(self, X_test: pd.DataFrame, y_test: pd.Series) -> Dict[str, Any]:
        """
        Single-round trust-aware federated learning (static trust).
        
        In heterogeneous client scenarios, this approach is strong because:
        - Clients weighted by trust scores (quality-based)
        - High-trust clients contribute more
        - Low-trust clients have minimal influence
        """
        print("\n" + "="*60)
        print("Approach 3: Trust-Aware Federated Learning (Single Round)")
        print("="*60)
        print("Note: Trust-Aware is strong in heterogeneous scenarios because")
        print("      it weights clients by quality (trust scores).")
        
        # Display trust scores
        print("\nClient Trust Scores (validation accuracy):")
        trust_scores = []
        for update in self.client_updates:
            trust = update.get('trust', 0)
            trust_scores.append(trust)
            print(f"  {update['client_id']}: {trust:.4f}")
        
        if trust_scores:
            trust_range = max(trust_scores) - min(trust_scores)
            print(f"\nTrust score range: {min(trust_scores):.4f} - {max(trust_scores):.4f} (range: {trust_range:.4f})")
            if trust_range > 0.3:
                print("  ✅ High heterogeneity - Trust-Aware can leverage quality differences!")
        
        # Use TrustAwareAggregator with retraining (true trust-aware FedAvg)
        print("\nAggregating client models with trust-weighted retraining (true trust-aware FedAvg)...")
        print("  Clients weighted by trust scores (quality-based weighting)")
        aggregator = TrustAwareAggregator(model_type=self.model_type)
        global_model = aggregator.aggregate(self.client_updates, use_retraining=True)
        
        # Display client weights
        weights = aggregator.get_client_weights(self.client_updates)
        print("\nClient Weights in Aggregation (trust-weighted):")
        for client_id, weight in sorted(weights.items(), key=lambda x: x[1], reverse=True):
            # Find corresponding trust score
            trust = next((u.get('trust', 0) for u in self.client_updates if u.get('client_id') == client_id), 0)
            print(f"  {client_id}: {weight:.4f} (trust: {trust:.4f})")
        
        # Show comparison with equal weights
        equal_weight = 1.0 / len(self.client_updates)
        print(f"\nComparison:")
        print(f"  Equal weight (FedAvg): {equal_weight:.4f} per client")
        print(f"  Trust-weighted: High-trust clients get more, low-trust get less")
        
        # Evaluate global model
        # Align test set features with training features (use first client's features as reference)
        if len(self.clients) > 0:
            X_test_aligned = X_test.reindex(columns=self.clients[0].X_train.columns, fill_value=0)
        else:
            X_test_aligned = X_test
        
        results = evaluate_model_on_test(global_model, X_test_aligned, y_test)
        
        print(f"\nTest Accuracy: {results['accuracy']:.4f}")
        print(f"Test F1-Score: {results['f1_score']:.4f}")
        print(f"Test Precision: {results['precision']:.4f}")
        print(f"Test Recall: {results['recall']:.4f}")
        print(f"False Positive Rate: {results['false_positive_rate']:.4f}")
        
        # Add note about strength
        if trust_scores and trust_range > 0.3:
            print("\n✅ Trust-Aware strength: Quality-based weighting prioritizes good clients")
            print("    High-trust clients contribute more, low-trust clients contribute less")
        
        return results
    
    def _approach_3_multi_round(self, X_test: pd.DataFrame, y_test: pd.Series) -> Dict[str, Any]:
        """Multi-round trust-aware federated learning with adaptive trust."""
        print("\n" + "="*60)
        print(f"Approach 3: Trust-Aware Federated Learning (Multi-Round: {self.num_rounds} rounds)")
        print("="*60)
        
        # Initialize clients in TrustManager
        for client in self.clients:
            self.trust_manager.initialize_client(client.client_id)
        
        global_model = None
        
        # Multi-round federated learning loop
        for round_num in range(1, self.num_rounds + 1):
            print(f"\n{'='*60}")
            print(f"Round {round_num}/{self.num_rounds}")
            print(f"{'='*60}")
            
            # DYNAMIC TRUST EVOLUTION: Inject changes to simulate compromise/improvement
            if round_num == 4:  # After round 3, some clients get compromised
                print("\n🔴 DYNAMIC EVENT: Some clients getting compromised (round 4)")
                # Select 2-3 compromised clients (low/compromised quality clients)
                compromised_clients = [
                    c for c in self.clients 
                    if 'low' in c.client_quality.lower() or 'compromised' in c.client_quality.lower()
                ][:3]  # Take up to 3
                for client in compromised_clients:
                    print(f"  ⚠️  {client.client_id}: Injecting additional corruption (simulating compromise)")
                    client.inject_dynamic_change(round_num, change_type='degrade', severity=0.4)
            
            elif round_num == 6:  # After round 5, some clients improve
                print("\n🟢 DYNAMIC EVENT: Some clients improving data quality (round 6)")
                # Select 2-3 medium-quality clients to improve
                improving_clients = [
                    c for c in self.clients 
                    if 'medium' in c.client_quality.lower()
                ][:2]  # Take up to 2
                for client in improving_clients:
                    print(f"  ✅ {client.client_id}: Restoring data quality (simulating improvement)")
                    client.inject_dynamic_change(round_num, change_type='improve', severity=0.5)
            
            # Phase 1: Local Training
            print("\nPhase 1: Local Training")
            for client in self.clients:
                client.train()
                client.evaluate()
                client.compute_trust()
            
            # Phase 2: Trust Update
            print("\nPhase 2: Trust Update")
            for client in self.clients:
                # Get the computed trust score (includes F1, gap penalty, train_acc penalty, etc.)
                computed_trust = client.trust_score
                
                # Debug: Print computed trust for compromised clients in round 1
                if round_num == 1 and 'compromised' in client.client_id.lower():
                    train_acc = client.train_metrics.get('train_accuracy', 0.0) if client.train_metrics else 0.0
                    val_acc = client.val_metrics['accuracy']
                    print(f"  DEBUG {client.client_id[:50]}: computed_trust={computed_trust:.4f}, "
                          f"train_acc={train_acc:.4f}, val_acc={val_acc:.4f}")
                
                # Get validation accuracy for logging
                val_acc = client.val_metrics['accuracy']
                perf_metrics = {
                    'validation_accuracy': val_acc,
                    'val_f1': client.val_metrics['f1_score'],
                    'val_precision': client.val_metrics['precision'],
                    'val_recall': client.val_metrics['recall'],
                    'train_accuracy': client.train_metrics.get('train_accuracy', 0.0) if client.train_metrics else 0.0
                }
                
                # Use the computed trust (from improved calculation) for adaptive trust update
                # The adaptive formula smooths the improved trust over rounds, not just validation accuracy
                # Get multi-signal signals if enabled
                multi_signal_signals = None
                if self.use_multi_signal:
                    try:
                        multi_signal_signals = client.compute_multi_signal_trust_signals()
                    except Exception as e:
                        logger.warning(f"Failed to compute multi-signal trust for {client.client_id}: {e}")
                        # Fallback to simple trust
                        multi_signal_signals = None
                
                updated_trust = self.trust_manager.update_trust(
                    client.client_id,
                    round_num,
                    computed_trust,  # Use computed trust instead of raw validation accuracy
                    perf_metrics,
                    multi_signal_signals=multi_signal_signals
                )
                
                # Update client's trust score
                client.trust_score = updated_trust
                
                # Check for anomalies
                anomaly = self.trust_manager.detect_anomaly(client.client_id)
                if anomaly:
                    print(f"  ⚠️  Anomaly detected for {client.client_id}: {anomaly['type']} (drop: {anomaly['magnitude']:.4f})")
            
            # Display updated trust scores and evolution
            print(f"\nUpdated Trust Scores (Round {round_num}):")
            all_trust = self.trust_manager.get_all_trust_scores()
            trust_list = []
            for client_id, trust in sorted(all_trust.items(), key=lambda x: x[1], reverse=True):
                trust_list.append(trust)
                # Get trust history to show change
                if client_id in self.trust_manager.trust_histories:
                    history = self.trust_manager.trust_histories[client_id]
                    if history and len(history.trust_scores) > 1:
                        prev_trust = history.trust_scores[-2] if len(history.trust_scores) > 1 else trust
                        change = trust - prev_trust
                        change_str = f" ({change:+.4f})" if abs(change) > 0.001 else " (stable)"
                        print(f"  {client_id}: {trust:.4f}{change_str}")
                    else:
                        print(f"  {client_id}: {trust:.4f}")
                else:
                    print(f"  {client_id}: {trust:.4f}")
            
            # Show trust evolution summary
            if round_num > 1 and trust_list:
                trust_range = max(trust_list) - min(trust_list)
                print(f"\nTrust Statistics (Round {round_num}):")
                print(f"  Range: {min(trust_list):.4f} - {max(trust_list):.4f} (range: {trust_range:.4f})")
                print(f"  Mean: {np.mean(trust_list):.4f}, Std: {np.std(trust_list):.4f}")
                if trust_range > 0.3:
                    print("  ✅ High heterogeneity - Trust-Aware adapts dynamically!")
                print("  📊 Trust scores change over rounds (dynamic) - FedAvg weights stay constant!")
            
            # Phase 3: Get Model Updates
            self.client_updates = [
                client.get_model_update(round_num=round_num) 
                for client in self.clients
            ]
            
            # Phase 4: Aggregation (using EnsembleAggregator for proper aggregation)
            print("\nPhase 3: Aggregation")
            
            # Update trust scores in client updates for ensemble aggregator
            all_trust = self.trust_manager.get_all_trust_scores()
            for update in self.client_updates:
                update['trust'] = all_trust.get(update['client_id'], update.get('trust', 0.5))
            
            # Use EnsembleAggregator with trust-weighted voting
            # Beta parameter controls sub-linear weighting (default: 0.8, optimal)
            ensemble = EnsembleAggregator(
                model_type=self.model_type, 
                aggregation_method='weighted_voting',
                beta=0.8  # Sub-linear trust weighting (consistent with TrustAwareAggregator)
            )
            ensemble.aggregate(self.client_updates)
            global_model = ensemble  # Store ensemble for potential use
            
            # Display client weights
            weights = ensemble.get_client_weights(self.client_updates)
            print("\nClient Weights in Aggregation:")
            for client_id, weight in weights.items():
                print(f"  {client_id}: {weight:.4f}")
            
            # Save trust history periodically
            if round_num % 5 == 0 or round_num == self.num_rounds:
                self.trust_manager.save_trust_history()
        
        # Final evaluation
        print(f"\n{'='*60}")
        print("Final Evaluation")
        print(f"{'='*60}")
        
        # Use the global model from last round (already retrained with trust weights)
        # Or re-aggregate with final trust scores if needed
        all_trust = self.trust_manager.get_all_trust_scores()
        for update in self.client_updates:
            update['trust'] = all_trust.get(update['client_id'], update.get('trust', 0.5))
        
        # Re-aggregate with final trust scores for final evaluation
        final_aggregator = TrustAwareAggregator(
            model_type=self.model_type,
            trust_manager=self.trust_manager
        )
        final_global_model = final_aggregator.aggregate(self.client_updates, use_retraining=True)
        
        # Align test set features with training features (use aggregator's training columns)
        if hasattr(final_aggregator, 'training_feature_columns') and final_aggregator.training_feature_columns:
            X_test_aligned = X_test.reindex(columns=final_aggregator.training_feature_columns, fill_value=0)
        elif len(self.clients) > 0:
            # Fallback: use all unique columns from all clients
            all_train_columns = set()
            for client in self.clients:
                all_train_columns.update(client.X_train.columns)
            all_train_columns = sorted(list(all_train_columns))
            X_test_aligned = X_test.reindex(columns=all_train_columns, fill_value=0)
        else:
            X_test_aligned = X_test
        
        results = evaluate_model_on_test(final_global_model, X_test_aligned, y_test)
        
        # Add trust statistics to results
        trust_stats = self.trust_manager.get_statistics()
        results['trust_statistics'] = trust_stats
        
        print(f"\nTest Accuracy: {results['accuracy']:.4f}")
        print(f"Test F1-Score: {results['f1_score']:.4f}")
        print(f"Test Precision: {results['precision']:.4f}")
        print(f"Test Recall: {results['recall']:.4f}")
        print(f"False Positive Rate: {results['false_positive_rate']:.4f}")
        
        print(f"\nTrust Statistics:")
        print(f"  Mean: {trust_stats['mean']:.4f}")
        print(f"  Std: {trust_stats['std']:.4f}")
        print(f"  Min: {trust_stats['min']:.4f}")
        print(f"  Max: {trust_stats['max']:.4f}")
        
        return results
    
    def run_experiment(self, num_clients: Optional[int] = None, num_rounds: Optional[int] = None) -> Dict[str, Any]:
        """
        Run the complete experiment.
        
        Args:
            num_clients: Number of clients to use (None = use all)
            num_rounds: Override num_rounds from initialization (optional)
            
        Returns:
            Complete results dictionary
        """
        if num_rounds is not None:
            self.num_rounds = num_rounds
        
        print("="*60)
        print("Trust-Aware Federated Honeypot Learning Experiment")
        if self.num_rounds > 1:
            print(f"Mode: Multi-Round ({self.num_rounds} rounds with adaptive trust)")
        else:
            print("Mode: Single-Round (static trust)")
        print("="*60)
        
        # Discover data files
        attack_files, benign_files = self.discover_client_files()
        
        if not attack_files:
            raise ValueError(f"No attack CSV files found in {self.data_dir}")
        
        # CRITICAL FIX: Reserve test file BEFORE setting up clients
        # This ensures test set is completely separate (no data leakage)
        # IMPORTANT: Use heterogeneous test set (matches training distribution)
        if self.test_csv is None and len(attack_files) > 1:
            # First, try to find pre-created heterogeneous test set
            heterogeneous_test_file = Path('data/CSVs/heterogeneous_test_set.csv')
            
            if heterogeneous_test_file.exists():
                # Use pre-created heterogeneous test set (matches training distribution)
                self.reserved_test_file = str(heterogeneous_test_file)
                attack_files_for_clients = attack_files  # Use all heterogeneous files for clients
                print(f"\n✅ RESERVED HETEROGENEOUS TEST SET (No Data Leakage):")
                print(f"   Test file: {Path(self.reserved_test_file).name}")
                print(f"   Matches training distribution (heterogeneous clients)")
                print(f"   Contains BOTH benign and attack samples")
                print(f"   This is realistic for honeypot evaluation")
            else:
                # Fallback: Try to find a mixed file (has both benign and attack samples)
                mixed_test_dir = Path('data/CSVs')
                mixed_files = sorted([f for f in mixed_test_dir.glob('mixed_*.csv') 
                                     if 'benign' not in f.name.lower()])
                
                if mixed_files:
                    # Use first mixed file as test set (has both classes)
                    self.reserved_test_file = str(mixed_files[0])
                    attack_files_for_clients = attack_files  # Use all heterogeneous files for clients
                    print(f"\n⚠️  RESERVED MIXED TEST FILE (No Data Leakage):")
                    print(f"   Test file: {Path(self.reserved_test_file).name}")
                    print(f"   ⚠️  WARNING: Mixed file may have different distribution than training")
                    print(f"   ⚠️  Consider creating heterogeneous_test_set.csv for better matching")
                else:
                    # Last resort: Prefer high-quality file for test set
                    high_quality_files = [f for f in attack_files if 'high_quality' in Path(f).name.lower()]
                    medium_quality_files = [f for f in attack_files if 'medium_quality' in Path(f).name.lower()]
                    
                    if high_quality_files:
                        self.reserved_test_file = high_quality_files[0]
                        attack_files_for_clients = [f for f in attack_files if f != self.reserved_test_file]
                        print(f"\n⚠️  RESERVED HIGH-QUALITY TEST FILE (No Data Leakage):")
                        print(f"   Test file: {Path(self.reserved_test_file).name}")
                        print(f"   ⚠️  WARNING: This file may only contain attack samples")
                        print(f"   ⚠️  Consider creating heterogeneous_test_set.csv for realistic evaluation")
                    elif medium_quality_files:
                        self.reserved_test_file = medium_quality_files[0]
                        attack_files_for_clients = [f for f in attack_files if f != self.reserved_test_file]
                        print(f"\n⚠️  RESERVED MEDIUM-QUALITY TEST FILE (No Data Leakage):")
                        print(f"   Test file: {Path(self.reserved_test_file).name}")
                        print(f"   ⚠️  WARNING: This file may only contain attack samples")
                    else:
                        self.reserved_test_file = attack_files[-1]
                        attack_files_for_clients = attack_files[:-1]
                        print(f"\n⚠️  RESERVED TEST FILE (No Data Leakage):")
                        print(f"   Test file: {Path(self.reserved_test_file).name}")
                        print(f"   ⚠️  WARNING: This file may only contain attack samples")
            
            print(f"   This file will NOT be used for any client training")
            print(f"   Total files: {len(attack_files)}, Clients: {len(attack_files_for_clients)}, Test: 1")
        else:
            self.reserved_test_file = None
            attack_files_for_clients = attack_files
        
        # Set up clients (using files that are NOT reserved for test)
        self.setup_clients(attack_files_for_clients, benign_files, num_clients=num_clients)
        
        # Train all clients
        self.train_clients()
        
        # Prepare test data - CRITICAL FIX: Use completely separate test set
        # Test set was reserved BEFORE training to avoid data leakage
        if self.test_csv is None:
            print("\n" + "="*60)
            print("PREPARING PROPER TEST SET (No Data Leakage)")
            print("="*60)
            
            if hasattr(self, 'reserved_test_file') and self.reserved_test_file:
                # Use the reserved test file (completely separate from training)
                print(f"\n✅ Using reserved test file: {Path(self.reserved_test_file).name}")
                print(f"   This file was NOT used for any client training")
                print(f"   ✅ NO DATA LEAKAGE - test set is completely unseen")
                X_test, y_test = self.prepare_test_data(self.reserved_test_file)
            else:
                # Fallback: Try to find a file not used by clients
                all_attack_files = sorted([str(f) for f in self.data_dir.glob('*.csv') 
                                         if 'benign' not in f.name.lower()])
                client_files = [c.data_path for c in self.clients]
                test_candidates = [f for f in all_attack_files if f not in client_files]
                
                if test_candidates:
                    test_file = test_candidates[0]
                    print(f"\n✅ Using separate file as test set: {Path(test_file).name}")
                    print(f"   This file was NOT used for any client training")
                    X_test, y_test = self.prepare_test_data(test_file)
                else:
                    # Last resort: Use original source data
                    print(f"\n⚠️  No separate test file available - using original source data")
                    source_dir = Path('~/Papers/CSVs').expanduser()
                    if source_dir.exists():
                        source_files = sorted([f for f in source_dir.glob('mixed_*.csv') 
                                             if 'benign' not in f.name.lower()])
                        if source_files:
                            test_file = source_files[0]
                            print(f"   Using original source: {test_file.name}")
                            X_test, y_test = self.prepare_test_data(str(test_file))
                        else:
                            print(f"   ⚠️  WARNING: Using validation data (not ideal)")
                            X_test = self.clients[0].X_val
                            y_test = self.clients[0].y_val
                    else:
                        print(f"   ⚠️  WARNING: Using validation data (not ideal)")
                        X_test = self.clients[0].X_val
                        y_test = self.clients[0].y_val
        else:
            # User provided test CSV
            X_test, y_test = self.prepare_test_data(self.test_csv)
        
        # Run all three approaches
        centralized_results = self.approach_1_centralized(X_test, y_test)
        federated_results = self.approach_2_federated_equal_weight(X_test, y_test)
        trust_aware_results = self.approach_3_trust_aware(X_test, y_test)
        
        # Generate summary
        client_info = [client.get_info() for client in self.clients]
        summary = generate_results_summary(
            centralized_results,
            federated_results,
            trust_aware_results,
            client_info,
            trust_manager=self.trust_manager if hasattr(self, 'trust_manager') else None
        )
        
        # Print comparison
        print("\n" + "="*60)
        print("RESULTS COMPARISON")
        print("="*60)
        print(f"\n{'Metric':<25} {'Centralized':<15} {'FedAvg':<15} {'Trust-Aware':<15}")
        print("-" * 70)
        print(f"{'Accuracy':<25} {centralized_results['accuracy']:<15.4f} {federated_results['accuracy']:<15.4f} {trust_aware_results['accuracy']:<15.4f}")
        print(f"{'F1-Score':<25} {centralized_results['f1_score']:<15.4f} {federated_results['f1_score']:<15.4f} {trust_aware_results['f1_score']:<15.4f}")
        print(f"{'Precision':<25} {centralized_results['precision']:<15.4f} {federated_results['precision']:<15.4f} {trust_aware_results['precision']:<15.4f}")
        print(f"{'Recall':<25} {centralized_results['recall']:<15.4f} {federated_results['recall']:<15.4f} {trust_aware_results['recall']:<15.4f}")
        print(f"{'False Positive Rate':<25} {centralized_results['false_positive_rate']:<15.4f} {federated_results['false_positive_rate']:<15.4f} {trust_aware_results['false_positive_rate']:<15.4f}")
        
        # Save results
        results_dict = {
            'centralized': centralized_results,
            'federated_equal_weight': federated_results,
            'trust_aware': trust_aware_results,
            'summary': summary
        }
        
        # Save to JSON
        os.makedirs('results/reports', exist_ok=True)
        with open('results/reports/experiment_results.json', 'w') as f:
            json.dump(results_dict, f, indent=2, default=str)
        print(f"\n✓ Results saved to results/reports/experiment_results.json")
        
        # Generate visualizations
        print("\nGenerating visualizations...")
        save_all_visualizations(
            client_info,
            {
                'centralized': centralized_results,
                'federated_equal_weight': federated_results,
                'trust_aware': trust_aware_results
            },
            output_dir='results/plots',
            trust_manager=self.trust_manager if hasattr(self, 'trust_manager') else None
        )
        
        return results_dict


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Trust-Aware Federated Honeypot Learning Experiment')
    parser.add_argument('--data-dir', type=str, default='data/CSVs',
                       help='Directory containing CSV files')
    parser.add_argument('--model-type', type=str, default='random_forest',
                       choices=['random_forest', 'logistic_regression', 'mlp', 'xgboost'],
                       help='Type of model to use')
    parser.add_argument('--num-clients', type=int, default=None,
                       help='Number of clients to use (None = use all)')
    parser.add_argument('--num-rounds', type=int, default=1,
                       help='Number of federated learning rounds (1 = single round, >1 = multi-round with adaptive trust)')
    parser.add_argument('--test-csv', type=str, default=None,
                       help='Path to test CSV file (optional)')
    parser.add_argument('--random-state', type=int, default=42,
                       help='Random seed')
    parser.add_argument('--trust-alpha', type=float, default=0.7,
                       help='History weight for adaptive trust (0.7 = 70%% old, 30%% new)')
    parser.add_argument('--trust-storage-dir', type=str, default=None,
                       help='Directory to store trust history (default: results/trust_history)')
    parser.add_argument('--multi-signal-trust', action='store_true',
                       help='Use multi-signal trust fusion (accuracy, stability, drift, uncertainty) instead of simple validation accuracy')
    parser.add_argument('--num-trials', type=int, default=1,
                       help='Number of independent trials for statistical validation (default: 1, recommended: 5-10)')
    
    args = parser.parse_args()
    
    # Run multiple trials if requested
    if args.num_trials > 1:
        print(f"\n{'='*60}")
        print(f"Running {args.num_trials} independent trials for statistical validation")
        print(f"{'='*60}\n")
        
        all_trial_results = []
        
        for trial in range(args.num_trials):
            print(f"\n{'='*60}")
            print(f"Trial {trial + 1}/{args.num_trials} (Seed: {args.random_state + trial})")
            print(f"{'='*60}\n")
            
            # Create runner with different seed for each trial
            runner = ExperimentRunner(
                data_dir=args.data_dir,
                model_type=args.model_type,
                random_state=args.random_state + trial,  # Different seed per trial
                test_csv=args.test_csv,
                num_rounds=args.num_rounds,
                trust_alpha=args.trust_alpha,
                trust_storage_dir=args.trust_storage_dir,
                use_multi_signal=args.multi_signal_trust
            )
            
            trial_results = runner.run_experiment(num_clients=args.num_clients)
            all_trial_results.append(trial_results)
        
        # Compute statistics across trials
        print("\n" + "="*60)
        print("STATISTICAL SUMMARY (Across All Trials)")
        print("="*60)
        
        # Extract metrics for each approach
        metrics = ['accuracy', 'f1_score', 'precision', 'recall', 'false_positive_rate', 'false_negative_rate']
        approach_names = ['centralized', 'federated_equal_weight', 'trust_aware']
        
        # Compute mean and std for each metric and approach
        stats_summary = {}
        for approach in approach_names:
            stats_summary[approach] = {}
            for metric in metrics:
                values = [trial_results[approach].get(metric, 0) for trial_results in all_trial_results 
                         if approach in trial_results and metric in trial_results[approach]]
                if values:
                    stats_summary[approach][metric] = {
                        'mean': np.mean(values),
                        'std': np.std(values),
                        'min': np.min(values),
                        'max': np.max(values)
                    }
        
        # Print statistical summary table
        print(f"\n{'Metric':<25} {'Centralized':<20} {'FedAvg':<20} {'Trust-Aware':<20}")
        print("-" * 85)
        for metric in metrics:
            metric_display = metric.replace('_', ' ').title()
            row = f"{metric_display:<25}"
            for approach in approach_names:
                if approach in stats_summary and metric in stats_summary[approach]:
                    mean_val = stats_summary[approach][metric]['mean']
                    std_val = stats_summary[approach][metric]['std']
                    row += f" {mean_val:.4f}±{std_val:.4f}  "
                else:
                    row += " " * 20
            print(row)
        
        # Save statistical summary
        stats_dict = {
            'num_trials': args.num_trials,
            'random_seeds': [args.random_state + i for i in range(args.num_trials)],
            'statistics': stats_summary,
            'all_trial_results': all_trial_results
        }
        
        os.makedirs('results/reports', exist_ok=True)
        with open('results/reports/statistical_summary.json', 'w') as f:
            json.dump(stats_dict, f, indent=2, default=str)
        print(f"\n✓ Statistical summary saved to results/reports/statistical_summary.json")
        
        # Perform statistical significance tests (t-test)
        print("\n" + "="*60)
        print("STATISTICAL SIGNIFICANCE TESTS (t-test)")
        print("="*60)
        
        if stats is None:
            print("Warning: scipy not available. Skipping statistical tests.")
            print("Install scipy with: pip install scipy")
        else:
            def perform_ttest(values1, values2, name1, name2, metric_name):
                """Perform t-test between two groups."""
                if len(values1) < 2 or len(values2) < 2:
                    return None, None
                t_stat, p_value = stats.ttest_ind(values1, values2)
                significance = "***" if p_value < 0.001 else "**" if p_value < 0.01 else "*" if p_value < 0.05 else "ns"
                print(f"\n{metric_name}: {name1} vs {name2}")
                print(f"  t-statistic: {t_stat:.4f}, p-value: {p_value:.4f} {significance}")
                return t_stat, p_value
            
            # Compare Trust-Aware vs FedAvg and vs Centralized
            for metric in metrics:
                if 'trust_aware' in stats_summary and metric in stats_summary['trust_aware']:
                    trust_values = [trial_results['trust_aware'].get(metric, 0) 
                                  for trial_results in all_trial_results 
                                  if 'trust_aware' in trial_results and metric in trial_results['trust_aware']]
                    
                    if 'federated_equal_weight' in stats_summary and metric in stats_summary['federated_equal_weight']:
                        fedavg_values = [trial_results['federated_equal_weight'].get(metric, 0) 
                                       for trial_results in all_trial_results 
                                       if 'federated_equal_weight' in trial_results and metric in trial_results['federated_equal_weight']]
                        perform_ttest(trust_values, fedavg_values, "Trust-Aware", "FedAvg", metric.replace('_', ' ').title())
                    
                    if 'centralized' in stats_summary and metric in stats_summary['centralized']:
                        centralized_values = [trial_results['centralized'].get(metric, 0) 
                                            for trial_results in all_trial_results 
                                            if 'centralized' in trial_results and metric in trial_results['centralized']]
                        perform_ttest(trust_values, centralized_values, "Trust-Aware", "Centralized", metric.replace('_', ' ').title())
            
            print("\nSignificance levels: *** p<0.001, ** p<0.01, * p<0.05, ns = not significant")
        
        results = stats_dict
    else:
        # Single trial (original behavior)
        runner = ExperimentRunner(
            data_dir=args.data_dir,
            model_type=args.model_type,
            random_state=args.random_state,
            test_csv=args.test_csv,
            num_rounds=args.num_rounds,
            trust_alpha=args.trust_alpha,
            trust_storage_dir=args.trust_storage_dir,
            use_multi_signal=args.multi_signal_trust
        )
        
        results = runner.run_experiment(num_clients=args.num_clients)
    
    print("\n" + "="*60)
    print("Experiment completed successfully!")
    print("="*60)


if __name__ == '__main__':
    main()
